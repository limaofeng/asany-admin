import { cloneWith } from 'lodash';
import React from 'react';
import AsanyEditor from '../../asany-editor';

import sketchPlugin from '../../sketch';
import Portal from '../Dashboard';

import * as components from '../../portal-components';

console.warn('📦 打包时, connect 逻辑会失效 TODO 临时解决方案 portal-components ', components);

const portalPlugin = cloneWith(sketchPlugin);

portalPlugin.id = 'portal';
portalPlugin.types = ['portal'];

interface RouteManagerProps {
  application: any;
}

function PortalBuilder(props: RouteManagerProps) {
  const {} = props;
  return (
    <AsanyEditor
      plugins={[portalPlugin]}
      onSave={(data) => console.log(data)}
      project={{
        id: 'basiclayout',
        name: '布局',
        type: 'portal',
        data: {
          id: 'com.thuni.his.layout.BasicLayout',
        } as any,
      }}
    >
      <Portal />
    </AsanyEditor>
  );
}

export default PortalBuilder;
