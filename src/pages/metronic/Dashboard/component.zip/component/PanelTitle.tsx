import React from 'react';
import classnames from 'classnames';
import useBlock from '../../asany-editor/hooks/useBlock';
import { ComponentPropertyType } from '../../library-manager/typings';
import { BellFilled } from '@ant-design/icons';

export interface PanelTab {
  id: string;
  icon?: string;
  title?: string;
  component?: string;
  control?: boolean;
  props?: any;
  theme?: string; // 主题色
}
export interface paramObj {
  ptitle?: string;
  theme?: string;
}

interface PanelProps {
  ptitle?: string;
  tabs?: PanelTab;
  panelTitleParams?: paramObj;
  parentBlockKey?: string;
}

function PanelTitleItem({ panelTitleParams }: PanelProps) {
  // xxx
  const tabTitle: string = panelTitleParams?.ptitle || '33标题';
  const [{ props }, portalTitle] = useBlock<any>({
    key: `panpelTitle`,
    icon: '',
    title: '标题',
    props: {
      title: tabTitle,
    },
    customizer: {
      fields: [
        {
          name: 'title',
          label: '标题',
          type: ComponentPropertyType.Text,
        },
        {
          name: 'icon',
          label: '图标',
          type: ComponentPropertyType.File,
          renderer: {
            component: 'Uploader',
            props: {
              mode: 'image',
              callBackMode: 'file',
              // defaultValue:{
              //   path:""
              // },
              options: {
                size: '60x60',
                text: '',
              },
            },
          },
        },
        {
          name: 'changeIcon',
          type: ComponentPropertyType.Text,
          label: '更换图标',
          renderer: {
            component: 'ThemeIcons',
            props: {
              mode: 'icon',
              // defaultValue:{
              //   path:""
              // },
            },
          },
        },
      ],
    },
  });
  return (
    <div
      className={classnames('portal-item-title', `portal-item-title-status-${status}`)}
      ref={portalTitle}
      style={{
        color: panelTitleParams?.theme,
      }}
    >
      <div>
        <i
          className="portal-item-icon"
          style={{
            background: panelTitleParams?.theme,
          }}
        >
          {props.icon ? <img src={props.icon?.path} /> : <BellFilled />}
        </i>
        <span className="portal-item-txt">{props.title || tabTitle}</span>
      </div>

      <div className="portal-more-btn">更多 &gt;</div>
    </div>
  );
}

export default React.memo(PanelTitleItem);
