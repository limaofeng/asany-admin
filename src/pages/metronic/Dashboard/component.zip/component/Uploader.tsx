import React, { useEffect, useState, useCallback } from 'react';
import Uploader from '../../uploader';
import { Button } from 'antd';

import { DeleteOutlined } from '@ant-design/icons';

//  图片渲染
interface RenderImageProps {
  size: string;
  path: string;
  callBack: (path?: string) => void;
}

function RenderImage(props: RenderImageProps) {
  let { size, path, callBack } = props;
  const [width, height] = size.split('x');
  return (
    <div
      className="image-card"
      style={{ width, height }}
      onClick={e => {
        e.stopPropagation();
        callBack();
      }}
    >
      <img
        src={path}
        style={{
          height: parseInt(height),
          width: parseInt(width),
          objectFit: 'cover',
        }}
      />
      <div className="image-card-model">
        <DeleteOutlined />
      </div>
    </div>
  );
}

interface IFileObject {
  id?: string;
  md5?: string;
  name?: string;
  path: string;
  mimeType?: string;
  length?: number;
}

function BannerImageUpData(props: any) {
  console.log('lln_props', props);
  const { defaultImages = [] } = props;
  const [images, setImages] = useState(defaultImages);
  const [, setUpLoadOpen] = useState(false);
  const hardChangeImages = useCallback(
    (file: any) => {
      let newData = [...images, file];
      setImages(newData);
      setUpLoadOpen(false);
    },
    [images]
  );

  useEffect(() => {
    props.onChange(images);
  }, [images]);

  //删除上传的图片
  const onReset = (_: string) => {
    setImages([]);
  };

  console.log('lln_images', images);
  return (
    <div className="configuration">
      <Button
        onClick={() => {
          setUpLoadOpen(true);
        }}
      >
        添加新图
      </Button>
      <div>
        {/* {openUpload &&
                    <div>
                        <Uploader {...props} onChange={hardChangeImages} />
                    </div>
                } */}

        <Uploader {...props} onChange={hardChangeImages} />
      </div>

      <div>
        {images &&
          !!images.length &&
          (images as IFileObject[]).map(item => {
            if (typeof item === 'string') {
              return <RenderImage size={'225x126' || '60x60'} path={item} callBack={onReset} />;
            } else {
              return <RenderImage size={'225x126' || '60x60'} path={item.path} callBack={onReset} />;
            }
          })}
      </div>
    </div>
  );
}
export default BannerImageUpData;
