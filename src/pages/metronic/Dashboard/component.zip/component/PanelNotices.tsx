import React from 'react';
import classnames from 'classnames';
import useBlock from '../../asany-editor/hooks/useBlock';
import { ComponentPropertyType } from '../../library-manager/typings';

export interface PanelTab {
  id: string;
  icon?: string;
  title?: string;
  component?: string;
  control?: boolean;
  features?: string[];
  props?: any;
  fontSize?: number; // 字体大小
  fontColor?: string; // 字体颜色
  content?: string; // 每项内容
  date?: string;
}

interface PanelProps {
  title?: string;
  tabs?: PanelTab[];
  parentBlockKey?: string;
}

function PanelNotices({ tabs: argTabs = [] }: PanelProps) {
  // xxx
  const tabs: PanelTab[] = !argTabs.length
    ? [
        { id: 'slider1', content: '内容1', fontColor: '#3e4r5s', date: '2020-06-04' },
        { id: 'slider4', content: '文章列表2', date: '2020-06-04' },
        { id: 'slider3', content: '文章列表3', title: '列表3', date: '2020-06-04' },
        { id: 'slider5', content: '文章列表1', date: '2020-06-04' },
        { id: 'slider6', content: '文章列表4', date: '2020-06-03' },
        { id: 'slider7', content: '文章列表6', date: '2020-06-02' },
        { id: 'slider8', content: '文章列表5', date: '2020-06-01' },
      ]
    : argTabs;

  const [{ props }, block] = useBlock<any>({
    key: `article`,
    icon: '',
    title: '文章列表',
    customizer: {
      fields: [
        {
          name: 'listArticle',
          label: '文章',
          type: ComponentPropertyType.Text,
        },
      ],
    },
  });

  // console.log('PanelArticle.props', props, tabs)
  return (
    <div ref={block} className={classnames('block-box-notice', `block-box-notice-status-${status}`)}>
      <ul className="panel-article">
        {tabs.map((item) => (
          <li
            key={item.id}
            style={{
              fontSize: item.fontSize,
              color: item.fontColor,
            }}
          >
            <span className="panel-article-content">{props.content || item.content}</span>
            <span className="panel-article-date">{props.date || item.date}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default React.memo(PanelNotices);
