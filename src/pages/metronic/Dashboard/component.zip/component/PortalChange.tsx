import React, { useState, useEffect } from 'react';

import { Radio } from 'antd';
import { RadioChangeEvent } from 'antd/es/radio';

import { useReduxSelector, useReduxDispatch } from '../../utils';

const PortalChange: React.FC = () => {
  // 门户缓存
  const portalCache = useReduxSelector((state) => state.portal) || {};
  // 有效门户
  const { validPortals = [], currentPortal = {} } = portalCache;
  // 默认选中
  const [checked, setChecked] = useState(currentPortal.id);

  useEffect(() => {
    setChecked(currentPortal.id);
  }, [currentPortal]);

  const dispatch = useReduxDispatch();

  const handleChange = (e: RadioChangeEvent) => {
    const { value } = e.target;

    setChecked(value);

    dispatch({ type: 'portal/changePortal', payload: value });
  };

  const defaultStyle: React.CSSProperties = {
    display: 'block',
    height: '30px',
    lineHeight: '30px',
  };

  const checkedStyle: React.CSSProperties = {
    display: 'block',
    height: '30px',
    lineHeight: '30px',
    color: '#1890ff',
  };

  return (
    <>
      <Radio.Group onChange={handleChange} value={checked}>
        {validPortals.map((e: any) => (
          <Radio style={e.id === checked ? checkedStyle : defaultStyle} value={e.id} key={e.id}>
            {e.name}
          </Radio>
        ))}
      </Radio.Group>
    </>
  );
};

export default PortalChange;
