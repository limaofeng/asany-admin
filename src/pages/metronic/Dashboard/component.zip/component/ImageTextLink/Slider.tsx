import { Slider, InputNumber, Row, Col } from 'antd';
import React from 'react';
type StateType = {
  inputValue: number;
};
type propType = {
  onChange: Function;
  max: number;
};
class IntegerStep extends React.Component<propType, StateType> {
  constructor(props: any) {
    super(props);
    this.state = {
      inputValue: 0,
    };
  }

  onChange = (value: number) => {
    this.setState(
      {
        inputValue: value,
      },
      () => {
        this.props.onChange && this.props.onChange(value);
      }
    );
  };

  render() {
    const { inputValue } = this.state;
    return (
      <Row>
        <Col span={20}>
          <Slider
            min={1}
            max={this.props.max}
            onChange={this.onChange}
            value={typeof inputValue === 'number' ? inputValue : 0}
          />
        </Col>
        <Col span={4}>
          <InputNumber
            min={1}
            max={this.props.max}
            style={{ margin: '0 8px' }}
            value={inputValue}
            onChange={this.onChange}
          />
        </Col>
      </Row>
    );
  }
}
export default IntegerStep;
