import React from 'react';
import { Cascader } from 'antd';
import { useReduxSelector } from '../../../utils';
interface RouterLinkStatus {
  onChange?: (data: any) => void;
  value?: string;
}
// const { useReduxSelector } = utils;
function getRouterTreeData(): any[] {
  debugger;
  let application = useReduxSelector((state: any) => state.global.application);
  if (!application) {
    return [];
  }
  let { routes } = application;
  const root: any[] = [];
  if (routes) {
    const routerMapTemp: any = {};
    routes = routes.filter((ele: any) => {
      routerMapTemp[ele.id] = ele;
      return ele.enabled && !ele.hideChildrenInMenu;
    });
    routes.forEach((ele: any) => {
      if (!ele.parent) {
        root.push(ele);
        return;
      }
      const parentEle = routerMapTemp[ele.parent.id];
      parentEle.children = [...(parentEle.children || []), ele];
    });
  }
  return root;
}
function RouterLinkSelect(props: RouterLinkStatus) {
  const { onChange } = props;
  const routerTree = getRouterTreeData();
  const onChangeRouter = (data: any, selectedOptions: any) => {
    console.log('选中的树节点', selectedOptions.lastItem);
    console.log('选中的树节点', data);
    onChange && onChange(selectedOptions.lastItem.path);
  };
  return (
    <div style={{ marginBottom: 16 }}>
      <Cascader
        options={routerTree}
        fieldNames={{ label: 'name', value: 'id', children: 'children' }}
        onChange={onChangeRouter}
        expandTrigger="hover"
      ></Cascader>
    </div>
  );
}
export default RouterLinkSelect;
