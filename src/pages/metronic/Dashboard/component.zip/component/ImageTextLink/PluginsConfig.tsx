import React from 'react';
import { ComponentPropertyType } from '../../../library-manager';
import WebsiteSelect from './WebsiteSelect';
import RouterLinkSelect from './RouterLinkSelect';
import ImageUpData from './ImageUpData';
import { Radio } from 'antd';
import Slider from './Slider';
enum TextPosition {
  TOP = 'top',
  BOTTOM = 'bottom',
  LEFT = 'left',
  RIGHT = 'right',
}
enum Shap {
  SQUARE = 'square',
  CIRCLE = 'circle',
}
const LinkDotPositionOptions = [
  <Radio.Button key={TextPosition.TOP} value={TextPosition.TOP}>
    上
  </Radio.Button>,
  <Radio.Button key={TextPosition.RIGHT} value={TextPosition.RIGHT}>
    右
  </Radio.Button>,
  <Radio.Button key={TextPosition.BOTTOM} value={TextPosition.BOTTOM}>
    下
  </Radio.Button>,
  <Radio.Button key={TextPosition.LEFT} value={TextPosition.LEFT}>
    左
  </Radio.Button>,
];
export default {
  getFields: () => [
    {
      name: 'uploadImage',
      label: '上传图片',
      type: ComponentPropertyType.Text,
      renderer: {
        component: ImageUpData,
        props: {
          min: 1,
          max: 20,
        },
      },
      group: '图片',
    },
    {
      name: 'imageBorderRadius',
      label: '图片角度',
      type: ComponentPropertyType.Text,
      visible: (props: any) => props.uploadImage,
      renderer: {
        component: Slider,
        props: {
          max: 50,
        },
      },
      group: '图片',
    },
    {
      name: 'imageHeight',
      label: '图片高度',
      type: ComponentPropertyType.Text,
      visible: (props: any) => props.uploadImage,
      renderer: {
        component: Slider,
        props: {
          max: 100,
        },
      },
      group: '图片',
    },
    {
      name: 'imageWidth',
      label: '图片宽度',
      type: ComponentPropertyType.Text,
      visible: (props: any) => props.uploadImage,
      renderer: {
        component: Slider,
        props: {
          max: 100,
        },
      },
      group: '图片',
    },
    {
      name: 'needBackgroundColor',
      label: '是否需要背景色',
      type: ComponentPropertyType.String,
      renderer: {
        component: 'Switch',
      },
      group: '图片',
    },
    {
      name: 'imageBackgroundColor',
      label: '背景色',
      type: ComponentPropertyType.String,
      visible: (props: any) => props.needBackgroundColor,
      renderer: {
        component: 'ColorPicker',
        props: {
          theme: 'Sketch',
        },
      },
      group: '图片',
    },
    // {
    //   name: 'imageBackgroundShap',
    //   label: '图片背景形状',
    //   type: ComponentPropertyType.Text,
    //   visible: (props: any) => props.needBackgroundColor,
    //   renderer: {
    //     component: 'RadioGroup',
    //     props: {
    //       buttonStyle: 'solid',
    //       children: imageBackgroundShapBtn,
    //     },
    //   },
    //   group: '图片',
    // },
    {
      name: 'imageBackgroundBorderRadius',
      label: '背景角度',
      type: ComponentPropertyType.Text,
      visible: (props: any) => props.needBackgroundColor,
      renderer: {
        component: Slider,
        props: {
          max: 50,
        },
      },
      group: '图片',
    },
    {
      name: 'backgroundHeight',
      label: '背景高度',
      type: ComponentPropertyType.Text,
      visible: (props: any) => props.needBackgroundColor,
      renderer: {
        component: Slider,
        props: {
          max: 100,
        },
      },
      group: '图片',
    },
    {
      name: 'backgroundWidth',
      label: '背景宽度',
      type: ComponentPropertyType.Text,
      visible: (props: any) => props.needBackgroundColor,
      renderer: {
        component: Slider,
        props: {
          max: 100,
        },
      },
      group: '图片',
    },
    {
      name: 'imageProportion',
      label: '图片位置占比（%）',
      type: ComponentPropertyType.Text,
      renderer: {
        component: 'InputNumber',
      },
      group: '图片',
    },
    {
      name: 'linkContent',
      label: '内容',
      type: ComponentPropertyType.Text,
      renderer: {
        component: 'Input',
      },
      group: '文字',
    },
    {
      name: 'fontSize',
      label: '字体大小',
      type: ComponentPropertyType.Text,
      renderer: {
        component: 'InputNumber',
        props: {
          min: 12,
        },
      },
      group: '文字',
    },
    {
      name: 'fontColor',
      label: '字体颜色',
      type: ComponentPropertyType.String,
      renderer: {
        component: 'ColorPicker',
        props: {
          theme: 'Sketch',
        },
      },
      group: '文字',
    },
    {
      name: 'dotPosition',
      label: '文字相对于图片位置',
      type: ComponentPropertyType.Text,
      renderer: {
        component: 'RadioGroup',
        props: {
          buttonStyle: 'solid',
          children: LinkDotPositionOptions,
        },
      },
      group: '文字',
    },
    {
      name: 'needBold',
      label: '加粗',
      type: ComponentPropertyType.String,
      renderer: {
        component: 'Switch',
      },
      group: '文字',
    },
    {
      name: 'needExternalLink',
      label: '外部链接',
      type: ComponentPropertyType.String,
      renderer: {
        component: 'Switch',
      },
      group: '链接',
    },
    {
      name: 'linkUrl',
      label: '网址',
      type: ComponentPropertyType.String,
      visible: (props: any) => props.needExternalLink,
      renderer: {
        component: WebsiteSelect,
      },
      group: '链接',
    },
    {
      name: 'linkRouterUrl',
      label: '路由地址',
      type: ComponentPropertyType.String,
      visible: (props: any) => !props.needExternalLink,
      renderer: {
        component: RouterLinkSelect,
      },
      group: '链接',
    },
    {
      name: 'needNewWindow',
      label: '新窗口',
      type: ComponentPropertyType.String,
      renderer: {
        component: 'Switch',
      },
      group: '链接',
    },
  ],
  TextPosition: TextPosition,
  Shap: Shap,
};
