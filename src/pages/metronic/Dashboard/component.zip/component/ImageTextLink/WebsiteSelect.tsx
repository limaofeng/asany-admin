import { Input, Select } from 'antd';
import React from 'react';
const { Option } = Select;
type StateType = {
  selectBeforeValue: string;
  inputValue: string;
  selectAfterValue: string;
};
type propType = {
  onChange: Function;
};
class WebsiteSelect extends React.Component<propType, StateType> {
  constructor(props: any) {
    super(props);
    this.state = {
      selectBeforeValue: 'http://',
      inputValue: 'mysite',
      selectAfterValue: '.com',
    };
  }
  onChangeSelect = (value: string, type: string) => {
    this.setState(
      {
        selectBeforeValue: type === 'selectBeforeValue' ? value : this.state.selectBeforeValue,
        inputValue: type === 'inputValue' ? value : this.state.inputValue,
        selectAfterValue: type === 'selectAfterValue' ? value : this.state.selectAfterValue,
      },
      () => {
        this.props.onChange &&
          this.props.onChange(`
        ${this.state.selectBeforeValue}${this.state.inputValue}${this.state.selectAfterValue}`);
      }
    );
  };
  render() {
    const { selectBeforeValue, selectAfterValue, inputValue } = this.state;
    const selectBefore = (
      <Select
        value={selectBeforeValue}
        className="select-before"
        onChange={(value: string) => {
          this.onChangeSelect(value, 'selectBeforeValue');
        }}
      >
        <Option value="http://">http://</Option>
        <Option value="https://">https://</Option>
      </Select>
    );
    const selectAfter = (
      <Select
        value={selectAfterValue}
        className="select-after"
        onChange={(value: string) => {
          this.onChangeSelect(value, 'selectAfterValue');
        }}
      >
        <Option value=".com">.com</Option>
        <Option value=".jp">.jp</Option>
        <Option value=".cn">.cn</Option>
        <Option value=".org">.org</Option>
      </Select>
    );
    return (
      <div style={{ marginBottom: 16 }}>
        <Input
          addonBefore={selectBefore}
          addonAfter={selectAfter}
          value={inputValue}
          onChange={({ target: { value } }) => {
            this.onChangeSelect(value, 'inputValue');
          }}
        />
      </div>
    );
  }
}
export default WebsiteSelect;
