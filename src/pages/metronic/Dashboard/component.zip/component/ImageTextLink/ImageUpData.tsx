import Uploader from '../../../uploader';
import React from 'react';

interface RouterLinkStatus {
  onChange?: (data: any) => void;
  value?: string;
}
function ImageUpData(props: RouterLinkStatus) {
  const { onChange, value } = props;
  const handleChange = async (img: any) => {
    const imgUrl = img?.path ?? img?.url ?? '';
    if (onChange) {
      await onChange(imgUrl);
    }
  };
  return (
    <div>
      <Uploader
        callBackMode="file"
        style={{ boxSizing: 'border-box' }}
        options={{ size: '102x102' }}
        mode="image"
        value={{
          uid: Date.now(),
          url: value,
        }}
        onChange={handleChange}
      />
    </div>
  );
}
export default ImageUpData;
