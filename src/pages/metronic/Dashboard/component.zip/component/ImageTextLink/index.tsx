import React from 'react';
import { useBlock } from '../../../asany-editor/hooks';
import './imageTextLink.less';
import PluginsConfig from './PluginsConfig';
import { ReactRouterDOM, Link } from '../../../utils';
import { compile } from 'path-to-regexp';
const { useHistory } = ReactRouterDOM;
interface ImageTextLinkBlockStatus {
  ImageUrl: string;
  dotPosition: string;
  fontSize: number;
  fontColor: string;
  linkContent: string;
  needBold: boolean;
  linkUrl: string;
  linkRouterUrl: string;
  needExternalLink: boolean;
  needNewWindow: boolean;
  uploadImage: string;
  imageHeight: number;
  imageWidth: number;
  needBackgroundColor: boolean;
  imageBackgroundColor: string;
  backgroundHeight: number;
  backgroundWidth: number;
  imageProportion: number;
  imageBackgroundBorderRadius: number;
  imageBorderRadius: number;
}
function ImageTextLink() {
  const [{ props: imageTextlinkProps, onClick }, block] = useBlock<ImageTextLinkBlockStatus>({
    key: 'ImageTextLink',
    icon: '',
    title: '图文链接',
    props: {
      dotPosition: PluginsConfig.TextPosition.TOP,
      fontSize: 12,
      fontColor: '#000',
      linkContent: '链接内容',
      ImageUrl: '',
      needBold: false,
      linkUrl: '',
      linkRouterUrl: '',
      needExternalLink: false,
      needNewWindow: false,
      uploadImage: '',
      imageHeight: 100,
      imageWidth: 100,
      needBackgroundColor: false,
      imageBackgroundColor: '#fff',
      backgroundHeight: 100,
      backgroundWidth: 100,
      imageProportion: 80,
      imageBackgroundBorderRadius: 0,
      imageBorderRadius: 0,
    },
    customizer: {
      fields: PluginsConfig.getFields(),
    },
  });
  const {
    dotPosition,
    fontSize,
    fontColor,
    linkContent,
    needBold,
    linkUrl,
    imageProportion,
    needNewWindow,
    uploadImage,
    imageHeight,
    imageWidth,
    needBackgroundColor,
    imageBackgroundColor,
    imageBackgroundBorderRadius,
    backgroundHeight,
    backgroundWidth,
    imageBorderRadius,
    needExternalLink,
    linkRouterUrl,
  } = imageTextlinkProps;
  function openUrl() {
    if (needExternalLink && needNewWindow) {
      window.open(linkUrl, '_blank');
    } else if (needExternalLink && !needNewWindow) {
      window.location.href = linkUrl;
    } else {
      changePage(linkRouterUrl);
    }
  }
  function changePage(url?: string) {
    const history = useHistory();
    history.push({
      pathname: url,
    });
  }
  return (
    <div
      className="image-link"
      ref={block}
      onClick={onClick}
      style={{
        width: '100%',
        display: 'flex',
        flexDirection:
          dotPosition === PluginsConfig.TextPosition.BOTTOM
            ? 'column'
            : dotPosition === PluginsConfig.TextPosition.TOP
            ? 'column-reverse'
            : dotPosition === PluginsConfig.TextPosition.LEFT
            ? 'row'
            : 'row-reverse',
      }}
    >
      {needBackgroundColor && (
        <div
          className="image-bg"
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            height: `${
              dotPosition === PluginsConfig.TextPosition.TOP || dotPosition === PluginsConfig.TextPosition.BOTTOM
                ? imageProportion
                : backgroundHeight
                ? backgroundHeight
                : 100
            }%`,
            width: `${
              dotPosition === PluginsConfig.TextPosition.LEFT || dotPosition === PluginsConfig.TextPosition.RIGHT
                ? imageProportion
                : backgroundWidth
                ? backgroundWidth
                : 100
            }%`,
            backgroundColor: imageBackgroundColor,
            // borderRadius: imageBackgroundShap === PluginsConfig.Shap.SQUARE ? '50%' :'0'
            borderRadius: `${imageBackgroundBorderRadius}%`,
          }}
        >
          {uploadImage && (
            <img
              style={{
                height: `${
                  dotPosition === PluginsConfig.TextPosition.TOP || dotPosition === PluginsConfig.TextPosition.BOTTOM
                    ? imageProportion
                    : imageHeight
                    ? imageHeight
                    : 100
                }%`,
                width: `${
                  dotPosition === PluginsConfig.TextPosition.LEFT || dotPosition === PluginsConfig.TextPosition.RIGHT
                    ? imageProportion
                    : imageWidth
                    ? imageWidth
                    : 100
                }%`,
                borderRadius: `${imageBorderRadius}%`,
              }}
              src={uploadImage}
            />
          )}
        </div>
      )}
      {!needBackgroundColor && uploadImage && (
        <img
          style={{
            height: `${
              dotPosition === PluginsConfig.TextPosition.TOP || dotPosition === PluginsConfig.TextPosition.BOTTOM
                ? imageProportion
                : imageHeight
                ? imageHeight
                : 100
            }%`,
            width: `${
              dotPosition === PluginsConfig.TextPosition.LEFT || dotPosition === PluginsConfig.TextPosition.RIGHT
                ? imageProportion
                : imageWidth
                ? imageWidth
                : 100
            }%`,
            borderRadius: `${imageBorderRadius}%`,
          }}
          src={uploadImage}
        />
      )}
      {needExternalLink ? (
        <a
          onClick={openUrl}
          style={{
            color: fontColor,
            fontSize: fontSize,
            fontWeight: needBold ? 'bold' : 'inherit',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          {linkContent}
        </a>
      ) : (
        <Link
          to={compile(linkRouterUrl || '')}
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <li
            style={{
              color: fontColor,
              fontSize: fontSize,
              fontWeight: needBold ? 'bold' : 'inherit',
              listStyle: 'none',
            }}
          >
            <span className="panel-article-content">{linkContent}</span>
          </li>
        </Link>
      )}
    </div>
  );
}
export default React.memo(ImageTextLink);
