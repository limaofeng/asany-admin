import React from 'react';
import { Select } from 'antd';
import { useQuery } from "@apollo/client";
import { GETORGANIZATIONID } from '../gqls/home';

const { Option } = Select;

interface SelectOrganzationsProps{
    onChange?:(data:string) => void;
    value?:string;
}

function SelectOrganzations(props: SelectOrganzationsProps) {
    const { onChange, value } = props;
    const { data } = useQuery(GETORGANIZATIONID);
    const { organizations = [] } = data || {};
    return (
      <Select
        onChange={(val: string) => {
          onChange && onChange(val);
        }}
        value={value}
      >
        {organizations.map((item: { value: string; label: string }) => {
          return (
            <Option key={item.value} value={item.value}>
              {item.label}
            </Option>
          );
        })}
      </Select>
    );
}
export default SelectOrganzations;