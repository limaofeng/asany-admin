import React from 'react';
import classnames from 'classnames';
import useBlock from '../../asany-editor/hooks/useBlock';
import { ComponentPropertyType } from '../../library-manager/typings';

export interface PanelTab {
  id: string;
  icon?: string;
  title?: string;
  component?: string;
  control?: boolean;
  features?: string[];
  props?: any;
  img?: string; // 图片路径
}

interface PanelProps {
  pImage?: string;
  tabs?: PanelTab[];
  parentBlockKey?: string;
}

function PanelImages({ pImage }: PanelProps) {
  // xxx
  // const tabs: PanelTab[] = !argTabs.length
  //   ? [
  //     { id: "slider1", img: 'http://test.thuni-h.com/upload/2020/06/04/15f56b16d8768ad586c1c5d1625db981.png' },
  //     // { id: "slider2", img: '' },
  //   ]
  //   : argTabs;

  const tabImage: string = pImage || 'http://test.thuni-h.com/upload/2020/06/04/15f56b16d8768ad586c1c5d1625db981.png';
  console.log('img', tabImage);
  const [{ props }, portalImg] = useBlock<any>({
    key: `panelImage`,
    icon: '',
    title: '背景图片',
    customizer: {
      fields: [
        {
          name: 'background',
          label: '图片上传',
          type: ComponentPropertyType.File,
          renderer: {
            component: 'Uploader',
            props: {
              defaultValue: tabImage,
              mode: 'image',
              callBackMode: 'file',
              options: {
                size: '225x126',
                text: '',
              },
            },
          },
          group: '登录背景',
        },
      ],
    },
  });

  // console.log('PanelImage.props', props, tabImage)
  // TODO `block-box-image-status-${status}`
  return (
    <div ref={portalImg} className={classnames('block-box-image')}>
      <img src={props?.background?.path || tabImage} />
    </div>
  );
}

export default React.memo(PanelImages);
